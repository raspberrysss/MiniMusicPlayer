﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Music2
{
    public partial class Form_SU : Form
    {
        public Form_SU()
        {
            InitializeComponent();
            label1.Text = "欢迎系统管理员" + now.name_now;
           
        }
        string s = "";
        string sname = "";
        int tmp = 0;
        List<int> tmps = new List<int>();
        List<string> ss = new List<string>();
        List<string> sms = new List<string>();
        private void check_to_mu_Click(object sender, EventArgs e)
        {
            lb_showall.Items.Clear();
            label1.Text = "以下为要审核的申请信息";
            DAO dao = new DAO();
            dao.connect();
            string sql = $"select * from Table_subinfo";
            SqlDataReader reader = dao.read(sql);
            
           
            //StringBuilder sub_show = new StringBuilder();
            //sub_show.Append("申请人 id      申请人用户名      申请人申请理由");
            s = "申请人 id      申请人用户名      申请人申请理由";

            lb_showall.Items.Add(s);
            while (reader.Read())
            {

                tmp = Convert.ToInt32(reader[0]);
                tmps.Add(tmp);
                sname = Convert.ToString(reader[1]);
                sms.Add(sname);
                s = Convert.ToString(reader[0]) + " " + Convert.ToString(reader[1]) + "                      " + Convert.ToString(reader[2]);
                ss.Add(s);
                lb_showall.Items.Add(s);
                //  sub_show.Append(Convert.ToString(reader[0]));
                //sub_show.Append("               ");
                //sub_show.Append(Convert.ToString(reader[1]));
                //sub_show.Append(Convert.ToString(reader[2]));


            }
            reader.Close();
            dao.Daoclose();

            //动态添加按钮
            Button btn1 = new Button();
            btn1.Text = "审核通过";
            btn1.Name = "btn_pass";
            btn1.Size = new Size(98, 36);
            btn1.Visible = true;
            btn1.Location = new Point(145, 385);
            Button btn2 = new Button();
            btn2.Text = "审核不通过";
            btn2.Name = "btn_nopass";
            btn2.Size = new Size(98, 36);
            btn2.Visible = true;
            btn2.Location = new Point(413, 385);
            this.Controls.Add(btn1);
            this.Controls.Add(btn2);
            btn1.Click += new EventHandler(btn1New_Click);
            btn2.Click += new EventHandler(btn2New_Click);
            //lb_showall.Items.Add(sub_show);


        }
        private void btn1New_Click(object sender,EventArgs e)
        {
            //审核通过，将其加入音乐人列表，并将其是否成功变换
            //添加成功或审核失败后，将其删除
            int id_mu = tmps[lb_showall.SelectedIndex - 1];
            string s_name = sms[lb_showall.SelectedIndex - 1];
            DAO dao = new DAO();
            dao.connect();
            string sql = $"insert into Table_musician values({id_mu},'{s_name}')";
            if(dao.Execute(sql)>0)
            {
                
                string sql2 = $"update T_User set is_sucess=1 where user_name='{s_name}'";
                if(dao.Execute(sql2)>0)
                {
                    //处理完后删除
                    string sql3 = $"delete from Table_subinfo where sub_user_name='{s_name}'";
                    if(dao.Execute(sql3)>0)
                    {
                        MessageBox.Show("添加成功");
                    }
                    //处理完再次显示一遍申请表
                    lb_showall.Items.Clear();
                    string sql4 = $"select * from Table_subinfo";
                    SqlDataReader reader = dao.read(sql4);
                    s = "申请人 id      申请人用户名      申请人申请理由";

                    lb_showall.Items.Add(s);
                    while (reader.Read())
                    {

                        tmp = Convert.ToInt32(reader[0]);
                        tmps.Add(tmp);
                        sname = Convert.ToString(reader[1]);
                        sms.Add(sname);
                        s = Convert.ToString(reader[0]) + " " + Convert.ToString(reader[1]) + "                      " + Convert.ToString(reader[2]);
                        ss.Add(s);
                        lb_showall.Items.Add(s);
                    }

                }
            }
            else
            {
                MessageBox.Show("添加失败");
            }
            dao.Daoclose();

        }

        private void btn2New_Click(object sender, EventArgs e)
        {
            //审核不通过，将其是否成功变换
            int id_mu = tmps[lb_showall.SelectedIndex - 1];
            string s_name = sms[lb_showall.SelectedIndex - 1];
            DAO dao = new DAO();
            dao.connect();
            string sql3 = $"update T_User set is_sucess=0 where user_name='{s_name}'";
            if (dao.Execute(sql3) > 0)
            {
                //处理后删除
                string sql4 = $"delete from Table_subinfo where sub_user_name='{s_name}'";
                if(dao.Execute(sql4)>0)
                {
                    MessageBox.Show("已将结果反馈给申请者");
                }
                //处理后显示
                lb_showall.Items.Clear();
                string sql5 = $"select * from Table_subinfo";
                SqlDataReader reader = dao.read(sql5);
                s = "申请人 id      申请人用户名      申请人申请理由";

                lb_showall.Items.Add(s);
                while (reader.Read())
                {

                    tmp = Convert.ToInt32(reader[0]);
                    tmps.Add(tmp);
                    sname = Convert.ToString(reader[1]);
                    sms.Add(sname);
                    s = Convert.ToString(reader[0]) + " " + Convert.ToString(reader[1]) + "                      " + Convert.ToString(reader[2]);
                    ss.Add(s);
                    lb_showall.Items.Add(s);
                }

            }
            else
            {
                MessageBox.Show("反馈失败");
            }
            //reader.close();
            dao.Daoclose();


        }
        string sd = "";
        int tmpd = 0;
        List<int> tmpsd = new List<int>();
        List<string> ssd = new List<string>();
        private void delete_user_Click(object sender, EventArgs e)
        {
            //把那两个按钮去掉，变成一个,去不掉，变成一个
            lb_showall.Items.Clear();
            Button btn3 = new Button();
            btn3.Text = "确认删除";
            btn3.Name = "btn_de";
            btn3.Size = new Size(75, 48);
            btn3.Visible = true;
            btn3.Location = new Point(646, 390);
            this.Controls.Add(btn3);
            btn3.Click += new EventHandler(btn3New_Click);

            label1.Text = "以下为申请注销的用户信息";
            DAO dao = new DAO();
            dao.connect();
            string sql = $"select * from T_subdelete";
            SqlDataReader reader = dao.read(sql);
            
            sd = "申请人 id      申请人用户名";
            lb_showall.Items.Add(sd);
            while (reader.Read())
            {

                tmpd = Convert.ToInt32(reader[0]);
                tmpsd.Add(tmpd);
                sd = Convert.ToString(reader[0]) + "                   " + Convert.ToString(reader[1]);
                ssd.Add(sd);
                lb_showall.Items.Add(sd);
                

            }
            reader.Close();
            dao.Daoclose();
        }
        private void btn3New_Click(object sender, EventArgs e)
        {
            int delete_id = tmpsd[lb_showall.SelectedIndex - 1];//第一行是表头
            DAO dao = new DAO();
            dao.connect();
            string sql =$"delete from T_User where user_no={delete_id}";
            if(dao.Execute(sql)>0)
            {
                string sql2 = $"delete from T_subdelete where id={delete_id}";
                if(dao.Execute(sql2)>0)
                {
                    MessageBox.Show("已成功删除");
                    string sql3 = $"delete from Table_musician where musician_no={delete_id}";
                    if(dao.Execute(sql3)>0)
                    {
                        MessageBox.Show("此用户为音乐人，已成功删除");
                    }
                }
                //删成功后在重新显示申请删除的表
                lb_showall.Items.Clear();
                string sql4 = $"select * from T_subdelete";
                SqlDataReader reader = dao.read(sql4);
                sd = "申请人 id      申请人用户名";
                lb_showall.Items.Add(sd);
                while (reader.Read())
                {

                    tmpd = Convert.ToInt32(reader[0]);
                    tmpsd.Add(tmpd);
                    sd = Convert.ToString(reader[0]) + "                   " + Convert.ToString(reader[1]);
                    ssd.Add(sd);
                    lb_showall.Items.Add(sd);


                }


            }
            else
            {
                MessageBox.Show("删除失败");
            }
            dao.Daoclose();

        }
    }
}
