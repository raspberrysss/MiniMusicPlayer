﻿namespace Music2
{
    partial class Form_User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_User));
            this.label_welcome = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.管理个人信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sub_to_deletemyself = new System.Windows.Forms.ToolStripMenuItem();
            this.sub_tobe_musician = new System.Windows.Forms.ToolStripMenuItem();
            this.评论歌曲ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pinglun = new System.Windows.Forms.ToolStripMenuItem();
            this.btn_before = new System.Windows.Forms.Button();
            this.btn_play = new System.Windows.Forms.Button();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_load = new System.Windows.Forms.Button();
            this.ls_showsong = new System.Windows.Forms.ListBox();
            this.btn_search = new System.Windows.Forms.Button();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.lb_lefttime = new System.Windows.Forms.Label();
            this.lb_righttime = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_songnanme = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.vol = new System.Windows.Forms.Label();
            this.Player = new AxWMPLib.AxWindowsMediaPlayer();
            this.btn_playway = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).BeginInit();
            this.SuspendLayout();
            // 
            // label_welcome
            // 
            this.label_welcome.AutoSize = true;
            this.label_welcome.Location = new System.Drawing.Point(15, 36);
            this.label_welcome.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label_welcome.Name = "label_welcome";
            this.label_welcome.Size = new System.Drawing.Size(76, 21);
            this.label_welcome.TabIndex = 0;
            this.label_welcome.Text = "label1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.管理个人信息ToolStripMenuItem,
            this.评论歌曲ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(589, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 管理个人信息ToolStripMenuItem
            // 
            this.管理个人信息ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sub_to_deletemyself,
            this.sub_tobe_musician});
            this.管理个人信息ToolStripMenuItem.Name = "管理个人信息ToolStripMenuItem";
            this.管理个人信息ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.管理个人信息ToolStripMenuItem.Text = "管理个人信息";
            // 
            // sub_to_deletemyself
            // 
            this.sub_to_deletemyself.Name = "sub_to_deletemyself";
            this.sub_to_deletemyself.Size = new System.Drawing.Size(160, 22);
            this.sub_to_deletemyself.Text = "申请注销";
            this.sub_to_deletemyself.Click += new System.EventHandler(this.sub_to_deletemyself_Click);
            // 
            // sub_tobe_musician
            // 
            this.sub_tobe_musician.Name = "sub_tobe_musician";
            this.sub_tobe_musician.Size = new System.Drawing.Size(160, 22);
            this.sub_tobe_musician.Text = "申请成为音乐人";
            this.sub_tobe_musician.Click += new System.EventHandler(this.sub_tobe_musician_Click);
            // 
            // 评论歌曲ToolStripMenuItem
            // 
            this.评论歌曲ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pinglun});
            this.评论歌曲ToolStripMenuItem.Name = "评论歌曲ToolStripMenuItem";
            this.评论歌曲ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.评论歌曲ToolStripMenuItem.Text = "评论";
            // 
            // pinglun
            // 
            this.pinglun.Name = "pinglun";
            this.pinglun.Size = new System.Drawing.Size(124, 22);
            this.pinglun.Text = "评论歌曲";
            this.pinglun.Click += new System.EventHandler(this.pinglun_Click);
            // 
            // btn_before
            // 
            this.btn_before.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_before.Location = new System.Drawing.Point(12, 350);
            this.btn_before.Name = "btn_before";
            this.btn_before.Size = new System.Drawing.Size(75, 31);
            this.btn_before.TabIndex = 2;
            this.btn_before.Text = "上一曲";
            this.btn_before.UseVisualStyleBackColor = true;
            this.btn_before.Click += new System.EventHandler(this.btn_before_Click);
            // 
            // btn_play
            // 
            this.btn_play.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_play.Location = new System.Drawing.Point(93, 350);
            this.btn_play.Name = "btn_play";
            this.btn_play.Size = new System.Drawing.Size(75, 31);
            this.btn_play.TabIndex = 3;
            this.btn_play.Text = "播放";
            this.btn_play.UseVisualStyleBackColor = true;
            this.btn_play.Click += new System.EventHandler(this.btn_play_Click);
            // 
            // btn_next
            // 
            this.btn_next.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_next.Location = new System.Drawing.Point(174, 350);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(75, 31);
            this.btn_next.TabIndex = 4;
            this.btn_next.Text = "下一曲";
            this.btn_next.UseVisualStyleBackColor = true;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // btn_load
            // 
            this.btn_load.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_load.Location = new System.Drawing.Point(322, 350);
            this.btn_load.Name = "btn_load";
            this.btn_load.Size = new System.Drawing.Size(75, 33);
            this.btn_load.TabIndex = 5;
            this.btn_load.Text = "导入";
            this.btn_load.UseVisualStyleBackColor = true;
            this.btn_load.Click += new System.EventHandler(this.btn_load_Click);
            // 
            // ls_showsong
            // 
            this.ls_showsong.FormattingEnabled = true;
            this.ls_showsong.ItemHeight = 21;
            this.ls_showsong.Location = new System.Drawing.Point(12, 101);
            this.ls_showsong.Name = "ls_showsong";
            this.ls_showsong.Size = new System.Drawing.Size(476, 151);
            this.ls_showsong.TabIndex = 7;
            this.ls_showsong.SelectedIndexChanged += new System.EventHandler(this.ls_showsong_SelectedIndexChanged);
            // 
            // btn_search
            // 
            this.btn_search.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_search.Location = new System.Drawing.Point(12, 60);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(88, 35);
            this.btn_search.TabIndex = 8;
            this.btn_search.Text = "搜索歌曲";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // txt_search
            // 
            this.txt_search.Location = new System.Drawing.Point(106, 64);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(382, 31);
            this.txt_search.TabIndex = 9;
            // 
            // lb_lefttime
            // 
            this.lb_lefttime.AutoSize = true;
            this.lb_lefttime.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_lefttime.Location = new System.Drawing.Point(8, 312);
            this.lb_lefttime.Name = "lb_lefttime";
            this.lb_lefttime.Size = new System.Drawing.Size(55, 20);
            this.lb_lefttime.TabIndex = 10;
            this.lb_lefttime.Text = "00：00";
            // 
            // lb_righttime
            // 
            this.lb_righttime.AutoSize = true;
            this.lb_righttime.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_righttime.Location = new System.Drawing.Point(485, 315);
            this.lb_righttime.Name = "lb_righttime";
            this.lb_righttime.Size = new System.Drawing.Size(55, 20);
            this.lb_righttime.TabIndex = 11;
            this.lb_righttime.Text = "00：00";
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(68, 312);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(420, 23);
            this.progressBar.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(14, 255);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 28);
            this.label3.TabIndex = 13;
            this.label3.Text = "正在播放：";
            // 
            // lb_songnanme
            // 
            this.lb_songnanme.AutoSize = true;
            this.lb_songnanme.Font = new System.Drawing.Font("微软雅黑", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_songnanme.Location = new System.Drawing.Point(120, 256);
            this.lb_songnanme.Name = "lb_songnanme";
            this.lb_songnanme.Size = new System.Drawing.Size(72, 27);
            this.lb_songnanme.TabIndex = 14;
            this.lb_songnanme.Text = "未播放";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(220, 288);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 21);
            this.label5.TabIndex = 15;
            this.label5.Text = "歌词";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(546, 310);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar1.Size = new System.Drawing.Size(45, 71);
            this.trackBar1.TabIndex = 16;
            this.trackBar1.Value = 20;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // vol
            // 
            this.vol.AutoSize = true;
            this.vol.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.vol.Location = new System.Drawing.Point(507, 361);
            this.vol.Name = "vol";
            this.vol.Size = new System.Drawing.Size(37, 20);
            this.vol.TabIndex = 17;
            this.vol.Text = "20%";
            // 
            // Player
            // 
            this.Player.Enabled = true;
            this.Player.Location = new System.Drawing.Point(262, 42);
            this.Player.Name = "Player";
            this.Player.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Player.OcxState")));
            this.Player.Size = new System.Drawing.Size(216, 23);
            this.Player.TabIndex = 18;
            this.Player.Visible = false;
            // 
            // btn_playway
            // 
            this.btn_playway.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_playway.Location = new System.Drawing.Point(403, 352);
            this.btn_playway.Name = "btn_playway";
            this.btn_playway.Size = new System.Drawing.Size(98, 31);
            this.btn_playway.TabIndex = 19;
            this.btn_playway.Text = "顺序播放";
            this.btn_playway.UseVisualStyleBackColor = true;
            this.btn_playway.Click += new System.EventHandler(this.btn_playway_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form_User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 393);
            this.Controls.Add(this.btn_playway);
            this.Controls.Add(this.Player);
            this.Controls.Add(this.vol);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lb_songnanme);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.lb_righttime);
            this.Controls.Add(this.lb_lefttime);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.ls_showsong);
            this.Controls.Add(this.btn_load);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.btn_play);
            this.Controls.Add(this.btn_before);
            this.Controls.Add(this.label_welcome);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("楷体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(6, 5, 6, 5);
            this.Name = "Form_User";
            this.Text = "Form_User";
            this.Load += new System.EventHandler(this.Form_User_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_welcome;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 管理个人信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sub_to_deletemyself;
        private System.Windows.Forms.ToolStripMenuItem sub_tobe_musician;
        private System.Windows.Forms.Button btn_before;
        private System.Windows.Forms.Button btn_play;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_load;
        private System.Windows.Forms.ListBox ls_showsong;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Label lb_lefttime;
        private System.Windows.Forms.Label lb_righttime;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_songnanme;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.Label vol;
        private AxWMPLib.AxWindowsMediaPlayer Player;
        private System.Windows.Forms.Button btn_playway;
        private System.Windows.Forms.ToolStripMenuItem 评论歌曲ToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem pinglun;
    }
}