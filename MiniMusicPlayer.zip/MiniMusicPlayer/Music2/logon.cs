﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Music2
{
    public partial class logon : Form
    {
        public logon()
        {
            InitializeComponent();
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            if(txt_logonname.Text==""||txt_logonpsw.Text==""||txt_queren.Text=="")
            {
                MessageBox.Show("不能有空项");
            }
            else
            {
                if (txt_logonpsw.Text.Length > 8)
                {
                    MessageBox.Show("密码不可超过八位");
                }
                else if (txt_logonpsw.Text!=txt_queren.Text)
                {
                    MessageBox.Show("密码与确认密码不一致！");
                }
                
                else
                {
                    //！在数据库里找，若没有同名的，加进去
                    DAO dao = new DAO();
                    dao.connect();
                    string user_name_logon = txt_logonname.Text;
                    string user_psw_logon = txt_logonpsw.Text;
                    string sql = $"select * from T_user where user_name='{user_name_logon}'";//！要加上‘’才会一个一个搜
                    SqlDataReader reader = dao.read(sql);
                    if(reader.Read()==true)
                    {
                        MessageBox.Show("用户名已被占用，请更换");
                    }
                    else//!无重复就添加
                    {
                        //把表末尾的第一个属性读出来转成int加一，再转为string
                        string sql2 = $"select TOP 1 user_no from T_user order by user_no desc";//!改成int类型了，也可以不选最后一条
                        reader = dao.read(sql2);
                        reader.Read();
                        int tmp = Convert.ToInt32(reader[0]);
                        Console.WriteLine(tmp);
                        tmp+=1;
                        string user_no_logon = Convert.ToString(tmp);
                        string sql3 = $"insert into T_user values('{user_no_logon}','{user_name_logon}','{user_psw_logon}',0,-1)";
                        if (dao.Execute(sql3)>0)
                        {
                            MessageBox.Show("注册成功");
                        }
                        else
                        {
                            MessageBox.Show("注册失败");
                        }
                        reader.Close();
                        dao.Daoclose();
                    }
                }
               
            }
           

            
        }
    }
}
