﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//用来连接数据库的类

namespace Music2
{
    class DAO
    {
        SqlConnection sc;//数据库连接对象
        public SqlConnection connect()//连接数据库
        {
            string str = @"Data Source=.;Initial Catalog=Music;Integrated Security=True";//连接串
            sc = new SqlConnection(str);
            sc.Open();
            return sc;
        }
        public SqlCommand command(string sql)//执行sql语句
        {
            SqlCommand cmd = new SqlCommand(sql, connect());
            return cmd;
        }
        public int Execute(string sql)//获取执行后数据库更新了几条
        {
            return command(sql).ExecuteNonQuery();
        }
        public SqlDataReader read(string sql)//读取数据库数据
        {
            return command(sql).ExecuteReader();
        }

        public void Daoclose()//关闭数据库
        {
            sc.Close();
        }

             

    }
}
