﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Music2
{
    class DATA
    {
       // public static string name="";
        //public static string password=""; //账号密码，从登入界面的文本信息上获取

        //public static string name_s = "";
        //public static string password_s = ""; //账号密码，从登入界面的文本信息上获取

        //！没有办法在这里写代码来控制控件
        /*public void login_u()//用户登录
        {
           
        }*/
    }
}
