﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Music2
{
    public partial class comment : Form
    {
        public comment()
        {
            InitializeComponent();
            label1.Text = "用户" + now.name_now;
            lb_showcom.Items.Add("用户名      评论歌曲      评论内容");
            DAO dao = new DAO();
            dao.connect();
            string sql = $"select * from T_C1";
            SqlDataReader reader = dao.read(sql);
            string s="";
            while(reader.Read())
            {
                s = Convert.ToString(reader[0]) + "          " + Convert.ToString(reader[1]) + "           " + Convert.ToString(reader[2]);
                lb_showcom.Items.Add(s);
            }
            dao.Daoclose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //！添加后把评论放在评论表
            String s1 = now.name_now;
            string s_n = txt_song.Text;
            string s_c = txt_comment.Text;
            if(s_c!=""&&s_n!="")
            {
                DAO dao = new DAO();
                dao.connect();
                string sql1 = $"insert into T_C1 values('{s1}','{s_n}','{s_c}')";
                if (dao.Execute(sql1) > 0)
                {
                    MessageBox.Show("评论成功");
                    string sql = $"select * from T_C1";
                    SqlDataReader reader = dao.read(sql);
                    string s = "";
                    while (reader.Read())
                    {
                        s = Convert.ToString(reader[0]) + "         " + Convert.ToString(reader[1]) + "         " + Convert.ToString(reader[2]);
                        lb_showcom.Items.Add(s);
                    }
                }

                dao.Daoclose();

            }
            else
            {
                MessageBox.Show("不可有空项");
            }


           
        }
    }
}
