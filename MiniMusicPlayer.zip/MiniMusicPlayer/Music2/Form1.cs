﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Music2
{
    
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        public void login_u()
        {
            //无法区分大小写
            string name = textname.Text;
            string psw = textpsw.Text;

            //数据库操作
            DAO dao = new DAO();
            dao.connect();
            string sql = $"select * from T_User where user_name='{name}' And user_password='{psw}'";
            SqlDataReader reader = dao.read(sql);
            if(reader.Read()==true)//只读一次就行
            {
                now.name_now = name;
                now.psw_now = psw;
                now.id =Convert.ToInt32(reader[0]);
                //string sql2 = $"select usr_no from T_User where user_name='{name}'";
                //reader = dao.read(sql2);
                //reader.Read();


                //把原界面的用户名和密码再次置空
                textname.Text = "";
                textpsw.Text = "";

                //关闭数据库
                reader.Close();
                dao.Daoclose();

                Form_User fu = new Form_User();
                fu.Show();
                //读到了，代表有这个用户，进入用户界面
            }
            else
            {
                MessageBox.Show("用户名或密码错误，请重新输入");
            }


            
            }
        public void login_su()
        {
            string names = textname.Text;
            string psws = textpsw.Text;

            //数据库操作
            DAO daos = new DAO();
            daos.connect();
            string sqls = $"select * from T_system where System_user_name='{names}' And System_user_password='{psws}'";
            SqlDataReader readers = daos.read(sqls);
            if (readers.Read() == true)//只读一次就行
            {
                now.name_now = names;
                now.psw_now = psws;
                

                //把原界面的用户名和密码再次置空
                textname.Text = "";
                textpsw.Text = "";

                //关闭数据库
                readers.Close();
                daos.Daoclose();

                Form_SU fus = new Form_SU();
                fus.Show();
                //读到了，代表有这个用户，进入用户界面
            }
            else
            {
                MessageBox.Show("用户名或密码错误，请重新输入");
            }
        }
        private void btn_login_Click(object sender, EventArgs e)
        {
            //登录功能
            //判断文本框是否有内容
            if (textname.Text == ""|| textpsw.Text == "")
            {
                MessageBox.Show("用户名或密码不能为空！");
            }
            else
            {
                if(rbtn_user.Checked==true)//用户登录
                {
                    login_u();
                }
                else if(rbtn_system_user.Checked==true)//管理员登录
                {
                       login_su();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            logon lg = new logon();
            lg.Show();
        }
    }
}
