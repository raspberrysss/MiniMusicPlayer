﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Music2
{
    public partial class Form_sub_info : Form
    {
        public Form_sub_info()
        {
            InitializeComponent();
            label3.Text = now.name_now;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //将内容放进表中，将普通表中对应用户改标志为1，1时出现等待审核的界面
            int no_subinfo = now.id;
            string name_suninfo = now.name_now;
            string text_info = textBox1.Text;
            if(textBox1.Text=="")
            {
                MessageBox.Show("申请内容不可为空");
            }
            else
            {
                DAO dao = new DAO();
                string sql = $"insert into Table_subinfo values({no_subinfo},'{name_suninfo}','{text_info}')";
                if(dao.Execute(sql)>0)
                {
                    
                    string sql2 = $"update T_User set is_sub=1 where user_name='{name_suninfo}'";
                    if(dao.Execute(sql2)>0)
                    {
                        MessageBox.Show("申请成功");
                    }
                }
                else
                {
                    MessageBox.Show("申请失败");
                }
                dao.Daoclose();

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
