﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music2
{
   public static class now
    {
        //用静态类实现！为什么不能直接用静态变量？
        public static string name_now = "", psw_now = "";//当前用户名和密码
        public static int id = 0;//当前用户编号
    }
}
