﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Music2
{
    public partial class Form_deletemy : Form
    {
        public Form_deletemy()
        {
            InitializeComponent();
            label1.Text = "用户" + now.name_now + "是否确认注销！";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //确认注销，将其加入申请注销表中,注销申请表为T_subdelete
            //now.id 为要加入的id，now.name 为要加入的用户名
            int id_subde = now.id;
            string name_subde = now.name_now;
            DAO dao = new DAO();
            dao.connect();
            string sql = $"insert into T_subdelete values({id_subde},'{name_subde}')";
            if(dao.Execute(sql)>0)
            {
                MessageBox.Show("申请注销成功");
            }
            else
            {
                MessageBox.Show("申请失败");
            }
            dao.Daoclose();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
