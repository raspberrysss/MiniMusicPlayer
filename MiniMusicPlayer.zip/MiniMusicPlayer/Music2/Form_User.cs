﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

using Newtonsoft.Json.Linq;
using Meting4Net.Core;
using NeteaseCloudMusicAPI.Api;
using NeteaseCloudMusicAPI.Api.Models;
using System.Text.RegularExpressions;

namespace Music2
{
    public partial class Form_User : Form
    {
        public Form_User()
        {
            InitializeComponent();
            Player.settings.volume = 20;
            //this.skinEngine1.SkinFile = "vista1_green.ssk";
        }

        private void Form_User_Load(object sender, EventArgs e)
        {
            label_welcome.Text = "欢迎" + now.name_now;
        }

        //StringBuilder files = new StringBuilder();//！要先初始化才能append
        // StringBuilder paths = new StringBuilder();
        //,paths;//提前写好，方便显示在listbox里
        string path1;
        //string file;
        List<string> localpath = new List<string>();
        //string[] files;
        //List<String> files = new List<string>();
       /* private const string SpotifyClientId = "raspberry";
        private const string SpotifyClientSecret = "hljtlsx8771104";
        private const string SpotifyApiBaseUrl = "https://api.spotify.com/v1";*/

        private void btn_load_Click(object sender, EventArgs e)
        {
            OpenFileDialog of = new OpenFileDialog();
            //of.Multiselect = true;//！可以一次性选多个,多个有问题，先不写
            of.Filter = "选择本地音乐文件|*.mp3;*wav;";
            if(of.ShowDialog()==DialogResult.OK)//打开成功
            {
          //      file=of.FileName;
                // paths.Append(of.FileName);
                path1 = of.FileName;
                localpath.Add(path1);
                ls_showsong.Items.Add(path1);
                //!已导入的歌曲存入数据库？
                //?每个用户一个表
                //files.Add(file);
                //paths.Append(of.FileName);
               /* foreach (string s in files)
                {
                    ls_showsong.Items.Add(s)                }*/

            }
           
        }

        private void ls_showsong_SelectedIndexChanged(object sender, EventArgs e)
        {
            //!先选中listbox里的一行，即播放
           
            if(localpath.Count()>0)
            {
                //Console.WriteLine(ls_showsong.SelectedIndex);
                Player.URL = localpath[ls_showsong.SelectedIndex];
                Player.Ctlcontrols.play();
                lb_songnanme.Text = Path.GetFileNameWithoutExtension(localpath[ls_showsong.SelectedIndex]);
            }
            btn_play.Text = "暂停";
            lrcstatus = splitlrctime_txt();

           
        }

        private void btn_play_Click(object sender, EventArgs e)
        {
            if(btn_play.Text=="暂停")
            {
                btn_play.Text = "播放";
                Player.Ctlcontrols.pause();
            }
            else if(btn_play.Text == "播放")
            {
                btn_play.Text = "暂停";
                Player.Ctlcontrols.play();
            }
        }

        private void btn_before_Click(object sender, EventArgs e)
        {
            /* if(ls_showsong.SelectedIndex>=0)
             {
                 if(ls_showsong.SelectedIndex==0)
                 {
                     ls_showsong.SelectedIndex = ls_showsong.Items.Count - 1;//等于0到最后一首

                 }
                 else
                 {
                     ls_showsong.SelectedIndex = ls_showsong.SelectedIndex - 1;
                 }
             }*/
            playMode(true);

        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            /* if(ls_showsong.SelectedIndex<=ls_showsong.Items.Count-1)
             {
                 if(ls_showsong.SelectedIndex== ls_showsong.Items.Count - 1)
                 {
                     ls_showsong.SelectedIndex = 0;
                 }
                 else
                 {
                     ls_showsong.SelectedIndex = ls_showsong.SelectedIndex + 1;
                 }
             }*/
            playMode(false);
        }

        private void btn_playway_Click(object sender, EventArgs e)
        {
            if(btn_playway.Text=="顺序播放")
            {
                btn_playway.Text = "随机播放";
                //播完的下一首是下标+1；
            }
            else if(btn_playway.Text == "随机播放")
            {
                btn_playway.Text = "单曲循环";
            }
            else if(btn_playway.Text == "单曲循环")
            {
                btn_playway.Text = "顺序播放";
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            Player.settings.volume = trackBar1.Value;
            vol.Text = trackBar1.Value + "%";
        }

        /*private void btn_showbendi_Click(object sender, EventArgs e)
        {
            //！先放着不做
            //ls_showsong.Items.Clear();
            
           /* foreach (string s in files)
            {
                ls_showsong.Items.Add(s);
            }
        }*/


        private void btn_search_Click(object sender, EventArgs e)
        {
            // CloudMusic.
            /*string s = txt_search.Text;
            string jsonStr = "";
            Meting api = new Meting(ServerProvider.Xiami);
            try
            {
                jsonStr = api.FormatMethod(true).Search(s, new Meting4Net.Core.Models.Standard.Options
                {
                    page = 1,
                    limit = 50
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("无歌曲");
            }
            finally { MessageBox.Show(jsonStr); }

            */
            // JArray jArray = JArray.Parse(jsonStr);



            /*string s = txt_search.Text;
            //用http的get方法获取网络api
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create($"http://search.kuwo.cn/r.s?all={s}&ft=music&itemset=web_2013&client=kt&pn=0&rn=5&rformat=json&encoding=utf8");//括号里写api地址
            request.Method = "GET";
            request.ContentType = "application/json;charset-UTF-8";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader sr = new StreamReader(response.GetResponseStream(), Encoding.UTF8);
            string json = sr.ReadToEnd();
            MessageBox.Show(json);*/
            //Console.WriteLine(json);

            /* searchTerm = txt_search.Text.Trim();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                // 获取访问令牌（Access Token）
                await GetAccessToken();

                if (!string.IsNullOrEmpty(accessToken))
                {
                    string searchUrl = $"{SpotifyApiBaseUrl}/search?q={HttpUtility.UrlEncode(searchTerm)}&type=track";
                    string searchResults = await SearchMusicAsync(searchUrl);

                    // 解析 API 响应并将结果显示在 ListBox 中
                   // DisplaySearchResults(searchResults);
                }
            }
            */
            //string SpotifyApiBaseUrl = "https://api.spotify.com/v1";
            /*
             * http://localhost:8080/play?rnd=123456.33？？？
           string s = txt_search.Text.Trim();
            string url = "";
            string responseContent = string.Empty;
            string postData = "{\"server\":\"1\",\"id\":\""+s+"\",\"ip\":\"127.0.0.1\"}";
            try
            {
                HttpWebRequest hwr = (HttpWebRequest)WebRequest.Create(url);
                byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                hwr.Method = "POST";
                hwr.ContentLength = byteArray.Length;
                hwr.ContentType = "application/json;charset=UTF-8";
                hwr.Headers.Add("x-requested-with","XMLHttpRequest");
                using (var stream  = hwr.GetRequestStream())
                {
                    stream.Write(byteArray, 0, byteArray.Length);
                    stream.Close();
                }
                using (HttpWebResponse response = (HttpWebResponse)hwr.GetResponse())
                {
                    using (StreamReader sr = new StreamReader(response.GetResponseStream(),Encoding.UTF8))
                    {
                        responseContent = sr.ReadToEnd();
                        Console.WriteLine(responseContent);
                        responseContent = "[" + responseContent + "]";
                        JArray jArray = JArray.Parse(responseContent);
                        foreach(var item in jArray)
                        {
                            foreach(var jarr in item["data"])
                            {
                                Console.WriteLine("11111");
                                ls_showsong.Items.Add(jarr["title"]);
                            }
                        }



                        sr.Close();
                        response.Close();
                    }
                }
            }
            catch(Exception ee)
            {
                Console.WriteLine(ee.Message);
            }
            */
        }

        /* private async Task GetAccessToken()
         {
             using (HttpClient client = new HttpClient())
             {
                 client.DefaultRequestHeaders.Add("Authorization", $"Basic {Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes($"{SpotifyClientId}:{SpotifyClientSecret}"))}");

                 var content = new FormUrlEncodedContent(new[]
                 {
                     new KeyValuePair<string, string>("grant_type", "client_credentials")
                 });

                 HttpResponseMessage response = await client.PostAsync("https://accounts.spotify.com/api/token", content);

                 if (response.IsSuccessStatusCode)
                 {
                     var result = await response.Content.ReadAsAsync<AccessTokenResponse>();
                     accessToken = result.AccessToken;
                 }
                 else
                 {
                     // 处理身份验证错误
                     accessToken = null;
                 }
             }
         }

         private async Task<string> SearchMusicAsync(string url)
         {
             using (HttpClient client = new HttpClient())
             {
                 client.DefaultRequestHeaders.Add("Authorization", $"Bearer {accessToken}");

                 try
                 {
                     HttpResponseMessage response = await client.GetAsync(url);

                     if (response.IsSuccessStatusCode)
                     {
                         return await response.Content.ReadAsStringAsync();
                     }
                     else
                     {
                         return $"Error: {response.StatusCode}";
                     }
                 }
                 catch (Exception ex)
                 {
                     return $"Error: {ex.Message}";
                 }
             }
         }
         public class AccessTokenResponse
         {
             public string AccessToken { get; set; }
             public string TokenType { get; set; }
             public int ExpiresIn { get; set; }
         }*/

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(Player.playState==WMPLib.WMPPlayState.wmppsPlaying)
            {
                progressBar.Maximum =(int) Player.Ctlcontrols.currentItem.duration;
                progressBar.Value =(int) Player.Ctlcontrols.currentPosition;
                lb_lefttime.Text = Player.Ctlcontrols.currentPositionString;
                lb_righttime.Text = Player.currentMedia.durationString;
                if(progressBar.Maximum==progressBar.Value)
                {
                    Player.Ctlcontrols.stop();
                }
                if(lrcstatus)
                {
                    //没显示出来
                    showlrc();
                }
                

            }
            else if (Player.playState == WMPLib.WMPPlayState.wmppsStopped)
            {
                playMode(true);
            }
        }
        public void playMode(bool mode)
        {
            if (btn_playway.Text == "顺序播放")
            {
                if (mode)
                {
                    if (ls_showsong.SelectedIndex >= 0)
                    {
                        if (ls_showsong.SelectedIndex == 0)
                        {
                            ls_showsong.SelectedIndex = ls_showsong.Items.Count - 1;//等于0到最后一首

                        }
                        else
                        {
                            ls_showsong.SelectedIndex = ls_showsong.SelectedIndex - 1;
                        }
                    }
                }
                else
                {
                    if (ls_showsong.SelectedIndex <= ls_showsong.Items.Count - 1)
                    {
                        if (ls_showsong.SelectedIndex == ls_showsong.Items.Count - 1)
                        {
                            ls_showsong.SelectedIndex = 0;
                        }
                        else
                        {
                            ls_showsong.SelectedIndex = ls_showsong.SelectedIndex + 1;
                        }
                    }
                }
            } 
            else if(btn_playway.Text == "随机播放")
            {
                Random random = new Random();
                int r = random.Next(0, ls_showsong.Items.Count);
                if(r==ls_showsong.SelectedIndex)
                {
                    //若随机到本身，则变为下一个或上一个
                    if ((r + 1) == ls_showsong.Items.Count) { r--; }//越界就减
                    else
                    {
                        r++;
                    }
                }
                if(localpath.Count>0)
                {
                    ls_showsong.SelectedIndex = r;
                    Player.URL = localpath[r];
                    Player.Ctlcontrols.play();
                    
                }


            }
            else if(btn_playway.Text == "单曲循环")
            {
                if (localpath.Count > 0)
                {
                    Player.URL = localpath[ls_showsong.SelectedIndex];
                    Player.Ctlcontrols.play();

                }
            }
        }

        private void sub_to_deletemyself_Click(object sender, EventArgs e)
        {
            Form_deletemy fd = new Form_deletemy();
            fd.Show();
        }

        private void sub_tobe_musician_Click(object sender, EventArgs e)
        {
            DAO dao = new DAO();
            dao.connect();
            string sql = $"select * from T_User where user_name='{now.name_now}'";
            SqlDataReader reader = dao.read(sql);
            reader.Read();
            int is_sub = Convert.ToInt32(reader[3]);
            int is_sucess = Convert.ToInt32(reader[4]);
            string sql2 = $"select * from Table_musician where musician_name='{now.name_now}'";
            reader = dao.read(sql2);
            if (reader.Read() == true)
            {
                MessageBox.Show("您已经是音乐人了");
            }
            else if (is_sub == 1 && is_sucess == 0)
            {
                MessageBox.Show("提交申请审核失败！");
            }
            else if (is_sub==1)
            {
                MessageBox.Show("您已提交过申请，正在审核中");
            }
            
            
            else
            {
                Form_sub_info fs = new Form_sub_info();
                fs.Show();
            }
            
        }

        private void pinglun_Click(object sender, EventArgs e)
        {
            comment cm = new comment();
            cm.Show();
        }
        const string locallrcpath = "D:\\music_lrc\\";
        bool lrcstatus = false;
        List<double> lrctime = new List<double>();
        List<string> lrctxt = new List<string>();

        public bool splitlrctime_txt()
        {
            try
            {
                string path_lrc =locallrcpath+Path.GetFileNameWithoutExtension(ls_showsong.SelectedItem.ToString()) + ".lrc";
                if(File.Exists(path_lrc))
                {
                    string[] arraystring = File.ReadAllLines(path_lrc, Encoding.UTF8 );//把歌词文件的全部内容全部装在一个string里
                    //!一行是一项
                    //MessageBox.Show(arraystring.ToString());
                    double total_count = 0;
                    foreach(var item in arraystring)
                    {
                        //Regex正则表达式类，用来匹配
                        if(Regex.IsMatch(item,@"[0-9][0-9]:[0-9][0-9].[0-9][0-9]"))
                        {
                            Match a = Regex.Match(item, @"[0-9][0-9]:[0-9][0-9].[0-9][0-9]");
                            Match b = Regex.Match(item, @"[^\d.\[\]:].{0,50}");
                           // MessageBox.Show(b.ToString());
                           // MessageBox.Show(a.ToString());

                            string time = a.ToString();
                            //MessageBox.Show(time.ToString());
                            string min = time.Split(new char[] {':'})[0];
                            string second = time.Split(new char[] { ':', ']' })[1];
                            double pmin = double.Parse(min) * 60;
                            double pse = double.Parse(second);

                            total_count = pmin + pse;
                            //MessageBox.Show(total_count.ToString());
                            lrctime.Add(total_count);
                            lrctxt.Add(b.ToString());
                        }
                    }
                    lrcstatus = true;
                }
                else
                {
                    lrcstatus = false;
                    label5.Text = "没有歌词";
                }
            }
            catch (Exception)
            {

                throw;
            }
            return lrcstatus;

        }
        public void showlrc()
        {
            if(ls_showsong.SelectedIndex>=0)
            {
                double currenttime = Player.Ctlcontrols.currentPosition;
                //MessageBox.Show(currenttime.ToString());
               // MessageBox.Show(lrctime[lrctime.Count - 1].ToString());
                if (currenttime>=lrctime[lrctime.Count-1])
                {
                    label5.Text = "歌词结束";

                }
                else
                {
                    for (int i = 0; i < lrctime.Count; i++)
                    {
                        if (currenttime > lrctime[i] && currenttime < lrctime[i++])
                        {
                            label5.Text = lrctxt[i];

                        }
                    }
                }
            }
        }
    }
    

}
